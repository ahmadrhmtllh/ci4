<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\Store_model;

class Store extends BaseController
{
    public function index()
    {
        $logged = session()->get('logged_in');

        if ($logged == TRUE) {

            $model = new Store_model();
            $data['store']  = $model->getStore()->getResult();

            echo template('StockCabang/view_store', $data);
        } else {

            return redirect()->to('/auth');
        }
    }

    public function getStore()
    {
        $model = new Store_model();
        $data  = $model->getStore()->getResult();

        echo json_encode($data);
    }

    public function save()
    {
        $model = new Store_model();
        $data = array(
            'name_store'        => $this->request->getPost('namastore'),
            'address_store' => $this->request->getPost('addressstore'),
            'telp_store' => $this->request->getPost('telpstore')
        );
        $data = $model->saveStore($data);
        echo json_encode($data);
    }

    public function editStore()
    {
        $model = new Store_model();
        $id = $this->request->getPost('idstore');
        $data = $model->editStore($id)->getResult();
        echo json_encode($data);
    }

    public function updateStore()
    {
        $model = new Store_model();
        $id = $this->request->getPost('idstore');
        $data = array(
            'name_store'        => $this->request->getPost('namastore'),
            'address_store' => $this->request->getPost('addressstore'),
            'telp_store' => $this->request->getPost('telpstore')
        );
        $data = $model->updateStore($data, $id);
        echo json_encode($data);
    }

    public function delete()
    {
        $model = new Store_model();
        $id = $this->request->getPost('idstore'); // dikirim dari :data{idstore:idstore} ajax
        $data = $model->deleteStore($id);
        echo json_encode($data);
    }
}

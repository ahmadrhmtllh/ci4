<?php

namespace App\Models; // Struktur Model

use App\Controllers\Product;
use CodeIgniter\Model;

class Mutasi_model extends Model
{
    protected $table = 'mutasi';

    public function getMutasi()
    {
        $builder = $this->db->table('mutasi');
        $builder->select('*');
        return $builder->get();
    }
    public function saveMutasi($data)
    {
        $query = $this->db->table('mutasi')->insert($data);
        return $query;
    }
    public function saveDetailMutasi($data)
    {
        $query = $this->db->table('mutasi_details')->insert($data);
        return $query;
    }
    public function LaporanMutasi($awal, $akhir)
    {
        $builder = $this->db->table('mutasi')
            ->join('stores', 'stores.id_store=mutasi.store_id')
            ->join('mutasi_details', 'mutasi_details.mutasi_id=mutasi.id_mutasi'); // menentukan tabel
        $builder->select('*'); // menentukan colom
        $builder->where('tgl_mutasi >=', $awal);
        $builder->where('tgl_mutasi <=', $akhir);
        $query = $builder->get(); // untuk eksekusi
        return $query;
    }
}
